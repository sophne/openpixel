OpenPixel Pixel Icons
=====================

2098 icons from Lucide 1.77, redrawn as 32x32 pixel art: a white 2px stroke, a 1px black
outline and a #4b4b55 shadow one pixel down and to the right.

png/        every icon as a 32x32 PNG (scale it up with nearest-neighbour)
svg/        every icon as an SVG of whole pixels
openpixel/  one OpenPixel file per category, one layer per icon

Change the colours and size, and copy or download single icons, at https://openpixel.dev/icons/library

MIT licence: see LICENSE.txt, which also carries the notice for the Lucide icons they are redrawn from.
